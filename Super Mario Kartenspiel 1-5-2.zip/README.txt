Super Mario Kartenspiel Version 1.5 (Eigentlich 1.5.2, ist aber nur eine kleine Fehlerkorrektur des Kartenscore-Systems darin)

I DO NOT OWN ANY OF NINTENDOS GRAPHICS AND I DO NOT GET ANY MONEY USING THESE GRAPHICS!